export const API = process.env.REACT_APP_API
export const gstSec = process.env.REACT_APP_GST_API_SEC
export const isAPIRun = process.env.REACT_APP_IS_API_RUN
