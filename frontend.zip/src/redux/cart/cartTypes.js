export const set_cart = 'set_cart'
export const set_cartToAddress = 'set_cartToAddress'
export const set_addressToPayment = 'set_addressToPayment' 
export const set_addressId = 'set_addressId' 

