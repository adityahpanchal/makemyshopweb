const SellerProfileUpdateMobile = () =>{
    return(
        <div>
            seller profile mobile
        </div>
    )
}

export default SellerProfileUpdateMobile