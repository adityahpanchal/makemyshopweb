const SellerProfile = () =>{
    return(
        <div>
            seller profile main
        </div>
    )
}

export default SellerProfile