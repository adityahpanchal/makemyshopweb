const SellerProfileUpdateLogo = () =>{
    return(
        <div>
            seller profile main
        </div>
    )
}

export default SellerProfileUpdateLogo