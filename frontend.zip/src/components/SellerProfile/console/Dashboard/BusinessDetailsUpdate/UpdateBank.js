const SellerProfileUpdateBank = () =>{
    return(
        <div>
            seller profile main
        </div>
    )
}

export default SellerProfileUpdateBank