import React from 'react'

export default function Test(props) {
    console.log('just test', props)
    return (
        <div>
            d
        </div>
    )
}
